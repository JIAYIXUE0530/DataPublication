<script>
    let props = $props();
    const { children } = props;
</script>

<nav>
    <h1>The Met Inventory Pages</h1>
    <a href="/">Home Page</a>
    <a href="/wheat-field">Wheat Field with Cypresses</a>
    <a href="/washington">Washington Crossing the Delaware</a>
</nav>
{@render children()}


<style>
    nav {
		background-color: maroon;
		color: white;
		font-family: Helvetica;
		font-weight: bold;
		padding-top: 1rem;
		padding-bottom: 1rem;
		padding-left: 1rem;
		padding-right: 1rem;
		border-radius: 8px;
        text-align: center;
	}
    a {
        color: whitesmoke;
    }
</style>