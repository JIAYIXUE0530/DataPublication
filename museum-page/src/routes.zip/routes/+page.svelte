<div style="text-align: center;">
    <h1>Welcome to The Met Inventory Pages</h1>
    <p>This website showcases two famous artworks from The Metropolitan Museum of Art:</p>
    <ul>
    <p style='color: grey'>Wheat Field with Cypresses by Vincent van Gogh</p>
    <p style='color: grey'>Washington Crossing the Delaware by Emanuel Leutze</p>
    </ul>
</div>